package src.main.java;

public class SimplePage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=12,bd=12;
		String name = "ff";
		System.out.print("Name:");
		System.out.print(name);
		System.out.print("AGE:");
		System.out.print(age);
		System.out.print("Birth Date:");
		System.out.print(bd);

	}

}
